require("dotenv").config();

const { Client, MessageEmbed } = require("discord.js");
const fetch = require("node-fetch");
const client = new Client();
const PREFIX = "y";

const ACTIVITIES = {
  "youtube": {
    id: "827938590620254218", // don't touch this
    name: "YouTube Together"
  },

};

client.on("ready", () => console.log("Bot is online!"));
client.on("warn", console.warn);
client.on("error", console.error);

// COMMAND HANDLER
client.on("message", async message => {
  if (message.author.bot || !message.guild) return;
  if (message.content.indexOf(PREFIX) !== 0) return;

  const args = message.content.slice(PREFIX.length).trim().split(" ");
  const cmd = args.shift().toLowerCase();
  //ping command
  if (cmd === "ping") return message.channel.send(`Pong! \`${client.ws.ping}ms\``);
  //youtube command
  if (cmd === "youtube") {
    const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
    let embed = new MessageEmbed()
      .setTitle('Error')
      .setDescription('❌ | The channel type have to be `Voice`')
      .setColor('RED')
    if (!channel || channel.type !== "voice") return message.channel.send(embed);
    if (!channel.permissionsFor(message.guild.me).has("CREATE_INSTANT_INVITE")) {
      let em = new MessageEMbed()
        .setTitle('Error')
        .setDescription('❌ | I need `CREATE_INSTANT_INVITE` permission')
        .setColor('RED')
      return message.channel.send(em);
    }

    fetch(`https://discord.com/api/v8/channels/${channel.id}/invites`, {
      method: "POST",
      body: JSON.stringify({
        max_age: 86400,
        max_uses: 0,
        target_application_id: "755600276941176913", // youtube together don't tocuch it
        target_type: 2,
        temporary: false,
        validate: null
      }),
      headers: {
        "Authorization": `Bot ${client.token}`,
        "Content-Type": "application/json"
      }
    })
      .then(res => res.json())
      .then(invite => {
        const eme = new MessageEmbed()
          .setTitle('Error')
          .setDescription('❌ | Could not start **YouTube Together**!')
          .setColor('RED')
        if (invite.error || !invite.code) return message.channel.send(eme);
        var emi = new MessageEmbed()
          .setTitle('Success')
          .setDescription(`[✅ | Click here to start **YouTube Together** in ${channel.name}](<https://discord.gg/${invite.code}>)`)
          .setColor('GREEN')
        message.channel.send(emi);
      })
      .catch(e => {
        message.channel.send(eme);
      })
  }
});


client.login("ODc1NDgzNzcxMTkxODM2NzMy.YRWLzA.TRPnFKGBO9kQifZwNU5ifWEslzw")